﻿#Connect-AzureRmAccount 
# https://docs.microsoft.com/en-us/cli/azure/account?view=azure-cli-latest#az-account-clear

$resourceGroup = "prem-rg"
$planName      = "appSvcPlan-S1"
$appName       = "premWebApp01"
$slot          = "dev01"

cls
az account clear
az login
az account list 

az account show
az account set --subscription bd218eea-d228-43ff-8e3f-a1813b35dada
az account set --subscription 8f5ada7a-86cc-46c1-9964-7c765e9ec9ec


Get-AzureRmSubscription | Select-Object Name, Id, TenantId, State
Set-AzureRmContext -SubscriptionId "bd218eea-d228-43ff-8e3f-a1813b35dada"
# Set-AzureRmContext -SubscriptionId "8f5ada7a-86cc-46c1-9964-7c765e9ec9ec"
# az webapp deployment slot list --name "Prem-WebApp-Via-CLI" --resource-group "prem-rg"

Select-AzureRmSubscription -SubscriptionId 8f5ada7a-86cc-46c1-9964-7c765e9ec9ec #-> For Visual Studio
Select-AzureRmSubscription -SubscriptionId bd218eea-d228-43ff-8e3f-a1813b35dada #-> For TPS-Dev

(Get-AzureRmContext).Subscription #-> Confirm the Subscription

Get-AzureRmResource  | Where-Object -FilterScript {$_.ResourceGroupName -like 'prem-rg'} | Select-Object Name, ResourceType, ResourceGroupName
#Install-Module -Name AzureRM -AllowClobber