$resourceGroup = "Prem-rg"
$planName="ServicePlan3e25283b-bc72"
$appName="Prem-WebApp-Via-CLI"
az webapp create -n $appName -g $resourceGroup --plan $planName

#Install-PackageProvider -Name NuGet -MinumumVersion 2.8.5.201 -Force