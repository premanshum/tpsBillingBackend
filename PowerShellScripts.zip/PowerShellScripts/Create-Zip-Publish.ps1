﻿
$publishFolder = "D:\Personal\Technical\Programs\InvoiceUIApp\dist"
$destination = "D:\publish\publish.zip"
if(Test-path $destination) {Remove-item $destination}
Add-Type -assembly "system.io.compression.filesystem"
[io.compression.zipfile]::CreateFromDirectory($publishFolder, $destination)

