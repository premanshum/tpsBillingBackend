﻿cls
Echo "Starting deployment..."
d:
cd D:\PremzWebApps\Invoice

# Variables
$resourceGroup = "prem-rg"
$planName      = "appSvcPlan-S1"
$appName       = "premWebApp01"
$slot          = "dev02"
$publishFolder = "D:\PremzWebApps\invoice" # -> Take from Publish folder
$destination = "D:\PremzWebApps\invoiceWebApi\Publish.zip" # -> Dump the publish file here

if(Test-path $destination) {Remove-item $destination}
Add-Type -assembly "system.io.compression.filesystem"
[io.compression.zipfile]::CreateFromDirectory($publishFolder, $destination)

ECHO $publishFolder 'has been zipped to location:' $destination

ECHO 'Copying Files...'

# Create a new WebApp/Slot
# New-AzureRmWebAppSlot -ResourceGroupName $resourceGroup -Name $appName -AppServicePlan $planName -Slot $slot

az webapp deployment source config-zip --name $appName --resource-group $resourceGroup  --src $destination --slot $slot

# Altering the App-Setting

$appSetting = @{'query01' = 'select top 20 * from dbo.BillRev'; 
                'Environment' = 'development'}
Set-AzureRmWebAppSlot -ResourceGroupName $resourceGroup -Name $appName -Slot $slot -AppSettings $appSetting


#az webapp config appsettings set --name $appName --resource-group $resourceGroup --slot $slot --slot-settings EnvViaAppSetting


# launch the site in a browser
$site2 = az webapp show -n $appName -g $resourceGroup --slot $slot --query "defaultHostName" -o tsv
Start-Process https://$site2