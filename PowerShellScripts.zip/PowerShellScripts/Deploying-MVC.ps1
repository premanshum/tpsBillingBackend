﻿cls
Echo "Starting deployment..."
d:
cd D:\Personal\Technical\Programs\DamnGood
$publishFolder = "D:\PremzWebApps\DamnGood"
$destination = "D:\PremzWebApps\DamnGoodPublish.zip"

if(Test-path $destination) {Remove-item $destination}

Add-Type -assembly "system.io.compression.filesystem"
[io.compression.zipfile]::CreateFromDirectory($publishFolder, $destination)

ECHO $publishFolder 'has been zipped to location:' $destination


$resourceGroup = "Prem-rg"
$planName      = "ServicePlan3e25283b-bc72"
$appName       = "Prem-WebApp-Via-CLI"
$slot          = "dev01"

# Need to check whether the WebApp/Slot exist before deleting

# Delete the WebApp/Slot
#Remove-AzureRmWebapp -Name $appName -ResourceGroupName $planName

# Create a new WebApp/Slot
#New-AzureRmWebAppSlot -ResourceGroupName $resourceGroup -Name $appName -AppServicePlan $planName -Slot $slot

# create a new webapp
#$appName="DamnGoodApp"

# Install the WebApp

ECHO 'Copying Files...'
# deploy publish.zip using the kudu zip api
az webapp deployment source config-zip --name $appName  --resource-group $resourceGroup  --src $destination --slot $slot

# Altering the App-Setting

$appSetting = @{'EnvViaAppSetting' = 'Development'; 
                'Image01Description' = 'The Gateway Arch is an iconic monument of St.Louis, overlooking the entire city. Here, the shadow of the Arch can be seen over the buildings, highways and park.'}
Set-AzureRmWebAppSlot -ResourceGroupName $resourceGroup -Name $appName -Slot $slot -AppSettings $appSetting


#az webapp config appsettings set --name $appName --resource-group $resourceGroup --slot $slot --slot-settings EnvViaAppSetting


# launch the site in a browser
$site2 = az webapp show -n $appName -g $resourceGroup --slot $slot --query "defaultHostName" -o tsv
Start-Process https://$site2