﻿$resourceGroup = "Prem-rg"
Get-AzureRmResource |
  Where-Object ResourceGroupName -eq $resourceGroup |
    Select-Object Name,Location,ResourceType